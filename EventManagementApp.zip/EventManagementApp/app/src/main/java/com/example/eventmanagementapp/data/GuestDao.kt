package com.example.eventmanagementapp.data

// 2. Guest DAO


import androidx.room.*
import com.example.eventmanagementapp.model.Guest
import kotlinx.coroutines.flow.Flow

@Dao
interface GuestDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGuest(guest: Guest)

    @Delete
    suspend fun deleteGuest(guest: Guest)

    @Query("SELECT * FROM guests ORDER BY name ASC")
    fun getAllGuests(): Flow<List<Guest>>
}

