package com.example.eventmanagementapp.ui.theme.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.eventmanagementapp.model.Schedule
import com.example.eventmanagementapp.ui.theme.DeepBlue80
import com.example.eventmanagementapp.viewmodel.ScheduleViewModel

@Composable
fun ScheduleListScreen(navController: NavController, viewModel: ScheduleViewModel = viewModel()) {
    val schedules by viewModel.scheduleList.collectAsState()
    var task by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text(
            text = "Schedule",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .background(DeepBlue80, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TextField(value = task, onValueChange = { task = it }, placeholder = { Text("Task") })
                TextField(value = time, onValueChange = { time = it }, placeholder = { Text("Time") })

                Button(onClick = {
                    if (task.isNotBlank() && time.isNotBlank()) {
                        viewModel.addSchedule(task, time)
                        task = ""; time = ""
                    }
                }) {
                    Text("Add Schedule")
                }

                Spacer(modifier = Modifier.height(20.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    schedules.forEach { schedule ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${schedule.task} at ${schedule.time}")
                            IconButton(onClick = { viewModel.deleteSchedule(schedule) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }

    }
}
