package com.example.eventmanagementapp.ui.theme.navigation

import HomeScreen
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.eventmanagementapp.ui.theme.screens.*

data class BottomNavItem<ImageVector>(val label: String, val icon: ImageVector, val route: String)

@Composable
fun AppNavGraph(navController: NavHostController = rememberNavController()) {
    val navItems = listOf(
        BottomNavItem("Guests", Icons.Default.Group, "guest_list"),
        BottomNavItem("Events", Icons.Default.Event, "event_list"),
        BottomNavItem("Schedule", Icons.Default.DateRange, "schedule_list"),
        BottomNavItem("Budget", Icons.Default.AttachMoney, "budget_list"),
        BottomNavItem("Vendors", Icons.Default.Business, "vendor_list")
        // Use Business instead of Store
    )


    Scaffold(
        bottomBar = {
            BottomNavigationBar(navController = navController, items = navItems)
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen(navController) }
            composable("guest_list") { GuestListScreen(navController) }
            composable("event_list") { EventListScreen(navController) }
            composable("schedule_list") { ScheduleListScreen(navController) }
            composable("budget_list") { BudgetListScreen(navController) }
            composable("vendor_list") { VendorListScreen(navController) }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController, items: List<BottomNavItem<ImageVector>>) {
    NavigationBar {
        val currentDestination = navController.currentBackStackEntryAsState().value?.destination
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                selected = currentDestination?.hierarchy?.any { it.route == item.route } == true,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}
