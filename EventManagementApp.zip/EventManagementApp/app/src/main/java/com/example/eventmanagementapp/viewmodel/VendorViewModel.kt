package com.example.eventmanagementapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventmanagementapp.data.AppDatabase
import com.example.eventmanagementapp.model.Vendor
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VendorViewModel(application: Application) : AndroidViewModel(application) {
    private val vendorDao = AppDatabase.getDatabase(application).vendorDao()
    val vendorList = vendorDao.getAllVendors().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addVendor(name: String, service: String, contact: String) {
        viewModelScope.launch {
            vendorDao.insertVendor(Vendor(name = name, service = service, contact = contact))
        }
    }

    fun deleteVendor(vendor: Vendor) {
        viewModelScope.launch {
            vendorDao.deleteVendor(vendor)
        }
    }
}