package com.example.eventmanagementapp.viewmodel


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventmanagementapp.data.AppDatabase
import com.example.eventmanagementapp.data.EventDao
import com.example.eventmanagementapp.model.Event
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EventViewModel(application: Application) : AndroidViewModel(application) {
    private val eventDao: EventDao = AppDatabase.getDatabase(application).eventDao()
    val eventList = eventDao.getAllEvents()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addEvent(title: String, date: String, location: String) {
        viewModelScope.launch {
            eventDao.insertEvent(Event(title = title, date = date, location = location))
        }
    }

    fun deleteEvent(event: Event) {
        viewModelScope.launch {
            eventDao.deleteEvent(event)
        }
    }
}
