package com.example.eventmanagementapp.ui.theme.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.eventmanagementapp.model.Event
import com.example.eventmanagementapp.ui.theme.DeepBlue80
import com.example.eventmanagementapp.viewmodel.EventViewModel

@Composable
fun EventListScreen(navController: NavController, viewModel: EventViewModel = viewModel()) {
    val events by viewModel.eventList.collectAsState()
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text(
            text = "Events",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .background(DeepBlue80, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Title") })
                TextField(
                    value = date,
                    onValueChange = { date = it },
                    placeholder = { Text("Date") })
                TextField(
                    value = location,
                    onValueChange = { location = it },
                    placeholder = { Text("Location") })

                Button(onClick = {
                    if (title.isNotBlank() && date.isNotBlank() && location.isNotBlank()) {
                        viewModel.addEvent(title, date, location)
                        title = ""; date = ""; location = ""
                    }
                }) {
                    Text("Add Event")
                }

                Spacer(modifier = Modifier.height(20.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    events.forEach { event ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${event.title} @ ${event.date} - ${event.location}")
                            IconButton(onClick = { viewModel.deleteEvent(event) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}
