package com.example.eventmanagementapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.eventmanagementapp.ui.theme.navigation.AppNavGraph
import com.example.eventmanagementapp.ui.theme.EventManagementAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EventManagementAppTheme {
                AppNavGraph()
            }
        }
    }
}
