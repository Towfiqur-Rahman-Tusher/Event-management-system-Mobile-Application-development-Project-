package com.example.eventmanagementapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventmanagementapp.data.AppDatabase
import com.example.eventmanagementapp.data.ScheduleDao
import com.example.eventmanagementapp.model.Schedule
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScheduleViewModel(application: Application) : AndroidViewModel(application) {
    private val scheduleDao: ScheduleDao = AppDatabase.getDatabase(application).scheduleDao()
    val scheduleList = scheduleDao.getAllSchedules()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addSchedule(task: String, time: String) {
        viewModelScope.launch {
            scheduleDao.insertSchedule(Schedule(task = task, time = time))
        }
    }

    fun deleteSchedule(schedule: Schedule) {
        viewModelScope.launch {
            scheduleDao.deleteSchedule(schedule)
        }
    }
}

