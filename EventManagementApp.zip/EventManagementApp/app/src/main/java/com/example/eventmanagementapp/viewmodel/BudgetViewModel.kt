package com.example.eventmanagementapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventmanagementapp.data.AppDatabase
import com.example.eventmanagementapp.model.Budget
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BudgetViewModel(application: Application) : AndroidViewModel(application) {

    private val budgetDao = AppDatabase.getDatabase(application).budgetDao()

    // Observe budgets as StateFlow
    val budgetList = budgetDao.getAllBudgets()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Add budget with optional expense
    fun addBudget(category: String, amount: Double, expense: Double = 0.0) {
        viewModelScope.launch {
            val budget = Budget(category = category, amount = amount, expense = expense)
            budgetDao.insertBudget(budget)
        }
    }

    // Delete a budget entry
    fun deleteBudget(budget: Budget) {
        viewModelScope.launch {
            budgetDao.deleteBudget(budget)
        }
    }

    // Update expense for an existing budget
    fun updateExpense(budget: Budget, newExpense: Double) {
        viewModelScope.launch {
            val updated = budget.copy(expense = newExpense)
            budgetDao.updateBudget(updated)
        }
    }
}
