package com.example.eventmanagementapp.data

// 3. AppDatabase


import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.eventmanagementapp.model.Budget
import com.example.eventmanagementapp.model.Event
import com.example.eventmanagementapp.model.Guest
import com.example.eventmanagementapp.model.Schedule
import com.example.eventmanagementapp.model.Vendor

@Database(entities = [Guest::class, Event::class, Schedule::class, Budget::class , Vendor::class ], version = 1)

abstract class AppDatabase : RoomDatabase() {
    abstract fun guestDao(): GuestDao
    abstract fun eventDao(): EventDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun budgetDao(): BudgetDao
    abstract fun vendorDao(): VendorDao


    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "event_management_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

