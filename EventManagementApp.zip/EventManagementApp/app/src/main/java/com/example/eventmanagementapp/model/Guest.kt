package com.example.eventmanagementapp.model

// 1. Guest Data Model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "guests")
data class Guest(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val contact: String
)
