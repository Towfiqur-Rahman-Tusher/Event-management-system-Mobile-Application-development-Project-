package com.example.eventmanagementapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventmanagementapp.data.AppDatabase
import com.example.eventmanagementapp.data.GuestDao
import com.example.eventmanagementapp.model.Guest
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GuestViewModel(application: Application) : AndroidViewModel(application) {
    private val guestDao: GuestDao = AppDatabase.getDatabase(application).guestDao()
    val guestList = guestDao.getAllGuests()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addGuest(name: String, contact: String) {
        viewModelScope.launch {
            guestDao.insertGuest(Guest(name = name, contact = contact))
        }
    }

    fun deleteGuest(guest: Guest) {
        viewModelScope.launch {
            guestDao.deleteGuest(guest)
        }
    }
}