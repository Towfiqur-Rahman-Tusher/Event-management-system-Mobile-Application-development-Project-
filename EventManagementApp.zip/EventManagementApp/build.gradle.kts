


// File: build.gradle.kts (Project root)

plugins {
    id("com.android.application") version "8.1.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.0" apply false
}

// ✅ Set Compose & Kotlin versions using Kotlin DSL `extra`, outside `buildscript`
extra.set("compose_ui_version", "1.5.0")
extra.set("kotlin_version", "1.9.0")

buildscript {
    repositories {
        google()
        mavenCentral()
    }

    dependencies {
        classpath("com.android.tools.build:gradle:8.1.1")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.0")
    }
}



