package com.example.eventmanager.data.dao

import com.example.eventmanager.data.model.User

class UserDaoImpl : UserDao {
    override suspend fun insert(user: User) {
        TODO("Not yet implemented")
    }

    override suspend fun login(
        username: String,
        password: String
    ): User? {
        TODO("Not yet implemented")
    }
}