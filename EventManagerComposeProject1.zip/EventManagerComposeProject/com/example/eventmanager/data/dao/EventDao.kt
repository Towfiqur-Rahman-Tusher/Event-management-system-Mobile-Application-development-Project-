package com.example.eventmanager.data.dao

import androidx.room.*
import com.example.eventmanager.data.model.Event

@Dao
interface EventDao {
    @Insert
    suspend fun insert(event: Event)

    @Update
    suspend fun update(event: Event)

    @Query("SELECT * FROM Event WHERE name LIKE '%' || :query || '%'")
    suspend fun search(query: String): List<Event>

    @Query("SELECT * FROM Event WHERE category = :category")
    suspend fun filterByCategory(category: String): List<Event>

    @Query("SELECT * FROM Event")
    suspend fun getAll(): List<Event>
}