package com.example.eventmanager.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.eventmanager.data.model.Event

@Composable
fun EventForm(onSubmit: (Event) -> Unit, initialEvent: Event? = null) {
    var name by remember { mutableStateOf(initialEvent?.name ?: "") }
    var desc by remember { mutableStateOf(initialEvent?.description ?: "") }
    var location by remember { mutableStateOf(initialEvent?.location ?: "") }
    var dateTime by remember { mutableStateOf(initialEvent?.dateTime ?: "") }
    var organizer by remember { mutableStateOf(initialEvent?.organizer ?: "") }
    var category by remember { mutableStateOf(initialEvent?.category ?: "") }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Event Name") })
        OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") })
        OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location") })
        OutlinedTextField(value = dateTime, onValueChange = { dateTime = it }, label = { Text("Date & Time") })
        OutlinedTextField(value = organizer, onValueChange = { organizer = it }, label = { Text("Organizer") })
        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") })

        Button(onClick = {
            onSubmit(Event(0, name, desc, location, dateTime, organizer, category))
        }) {
            Text("Save Event")
        }
    }
}